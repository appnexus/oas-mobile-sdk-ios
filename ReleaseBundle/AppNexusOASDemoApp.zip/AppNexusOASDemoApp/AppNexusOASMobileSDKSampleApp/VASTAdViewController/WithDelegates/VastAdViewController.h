

#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"
#import <MediaPlayer/MediaPlayer.h>

@interface VastAdViewController : UIViewController <XAdViewDelegate>
{
  //  MPMoviePlayerController *moviePlayerControllerInstance;
}
@property (nonatomic,strong) MPMoviePlayerController *moviePlayerControllerInstance;
@end
