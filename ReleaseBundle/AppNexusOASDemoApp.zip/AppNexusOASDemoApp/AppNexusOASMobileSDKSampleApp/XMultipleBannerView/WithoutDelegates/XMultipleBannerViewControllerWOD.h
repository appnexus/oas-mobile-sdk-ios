
#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface XMultipleBannerViewControllerWOD : UIViewController<XAdViewDelegate>

@end
