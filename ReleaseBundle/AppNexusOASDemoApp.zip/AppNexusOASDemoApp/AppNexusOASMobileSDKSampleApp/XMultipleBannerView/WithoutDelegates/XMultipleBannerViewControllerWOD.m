
#import "XMultipleBannerViewControllerWOD.h"

@interface XMultipleBannerViewControllerWOD ()

@property(nonatomic,strong)XAdView *bannerAdViewTop;
@property(nonatomic,strong)XAdView *bannerAdViewBottom;

@end


@implementation XMultipleBannerViewControllerWOD

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)intializingAd
{
    /* Initialising the XAdView and fetching the ad */
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.edgesForExtendedLayout = UIRectEdgeNone; // For iOS 7 support.
    }
    
    [self.view addSubview:self.bannerAdViewTop];
    
    self.bannerAdViewTop = [[XAdView alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 320)/2, 0, 320, 50)];
    self.bannerAdViewBottom = [[XAdView alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 320)/2, (self.view.frame.size.height-80), 320, 80)];
    
    
    self.bannerAdViewTop.delegate = self;
    self.bannerAdViewBottom.delegate = self;
    self.bannerAdViewTop.backgroundColor = [UIColor clearColor];
    self.bannerAdViewBottom.backgroundColor=[UIColor clearColor];
    

    XAdSlotConfiguration *configuration = [[XAdSlotConfiguration alloc] init];
    configuration.RTBRequired = NO;
    configuration.scalingAllowed = YES;
    configuration.shouldOpenClickThroughURLInAppBrowser = YES;
    configuration.mediationBannerHeight = 50;
    configuration.mediationBannerWidth = 320;
    configuration.mediationPlacementId = @"40";
    configuration.canMediate = YES;
    
    [self.bannerAdViewTop setSlotConfiguration:configuration];
    [self.bannerAdViewBottom setSlotConfiguration:configuration];

    [self.view addSubview:self.bannerAdViewTop];
    [self.bannerAdViewTop loadWithDomainName:@"oasc-training7.247realmedia.com" pageName:@"demo-ads.com" adPosition:@"@Top"];
    
    
    [self.view addSubview:self.bannerAdViewBottom];
    [self.bannerAdViewBottom loadWithDomainName:@"oasc-training7.247realmedia.com" pageName:@"demo-ads.com" adPosition:@"@Top"];
    
    self.bannerAdViewBottom.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [self intializingAd];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self orientationDidChange];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark orientation

-(BOOL)shouldAutorotate
{
    [self orientationDidChange];
    return YES;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}

-(void) orientationDidChange
{
    CGRect bounds = [[UIScreen mainScreen] bounds]; // portrait bounds
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) && NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    
    CGRect frame = self.bannerAdViewTop.frame;
    frame.origin.x = (bounds.size.width - self.bannerAdViewTop.frame.size.width)/2;
    self.bannerAdViewTop.frame = frame;
    
    CGRect frame1 = self.bannerAdViewBottom.frame;
    frame1.origin.x = (bounds.size.width - self.bannerAdViewBottom.frame.size.width)/2;
    self.bannerAdViewBottom.frame = frame1;

}


@end
