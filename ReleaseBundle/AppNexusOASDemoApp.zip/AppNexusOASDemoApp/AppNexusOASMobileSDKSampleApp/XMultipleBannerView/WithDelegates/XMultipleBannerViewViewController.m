
#import "XMultipleBannerViewViewController.h"

@interface XMultipleBannerViewViewController (){
    NSDictionary *myParameters;
    XClickToAction myActionType;

}

@property(nonatomic,strong)XAdView *bannerAdViewTop;
@property(nonatomic,strong)XAdView *bannerAdViewBottom;

@end


@implementation XMultipleBannerViewViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [self intializingAd];
}


-(void)intializingAd
{
    /* Initialising the XAdView and fetching the ad */
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.edgesForExtendedLayout = UIRectEdgeNone; // For iOS 7 support.
    }

    [self.view addSubview:self.bannerAdViewTop];
    
    self.bannerAdViewTop = [[XAdView alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 320)/2, 0, 320, 50)];
     self.bannerAdViewBottom = [[XAdView alloc]initWithFrame:CGRectMake((self.view.frame.size.width - 320)/2, (self.view.frame.size.height-80), 320, 80)];
    
    self.bannerAdViewTop.delegate = self;
    self.bannerAdViewBottom.delegate = self;
    self.bannerAdViewTop.backgroundColor = [UIColor clearColor];
    self.bannerAdViewBottom.backgroundColor=[UIColor clearColor];
    
    XAdSlotConfiguration *configuration = [[XAdSlotConfiguration alloc] init];
    configuration.RTBRequired = NO;
    configuration.scalingAllowed = NO;
    configuration.shouldOpenClickThroughURLInAppBrowser = YES;
    configuration.mediationBannerHeight = 50;
    configuration.mediationBannerWidth = 320;
    configuration.mediationPlacementId = @"40";
    configuration.canMediate = YES;

    [self.bannerAdViewTop setSlotConfiguration:configuration];
    [self.bannerAdViewBottom setSlotConfiguration:configuration];
    
    [self.view addSubview:self.bannerAdViewTop];
    [self.bannerAdViewTop loadWithDomainName:@"oasc-training7.247realmedia.com" pageName:@"demo-ads.com" adPosition:@"@Top"];
   
    
    [self.view addSubview:self.bannerAdViewBottom];
    [self.bannerAdViewBottom loadWithDomainName:@"oasc-training7.247realmedia.com" pageName:@"demo-ads.com" adPosition:@"@Top"];
     self.bannerAdViewBottom.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self orientationDidChange];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)writeEntry:(NSString*)entry
{
    NSString* text = [self.textView.text stringByAppendingFormat:@"\n%@\n--", entry];
    self.textView.text = text;
    
    [self.textView scrollRangeToVisible:NSMakeRange(text.length, 0)];
}

#pragma mark XAdView Delegates

-(void)xAdViewDidLoad:(XAdView *)adView
{
    if(adView==self.bannerAdViewTop)
    {
        [self writeEntry:@"xAdViewDidLoad : The Banner Top View Ad was loaded successfully"];
    }else{
        [self writeEntry:@"xAdViewDidLoad : The Banner Bottom View Ad was loaded successfully"];
    }
    
}

-(void)xAdView:(XAdView *)xAdView didFailWithError:(NSError *)error
{
    if(xAdView==self.bannerAdViewTop)
    {
        [self writeEntry:@"xAdViewDidFailWithError : The Banner Top View Ad failed to load"];
    }else{
        [self writeEntry:@"xAdViewDidFailWithError : The Banner Bottom View Ad failed to load"];
    }
}

- (void)xAdWillLoad:(XAdView *)adView{
    
}

- (void)xAdDidExpand:(XAdView *)adView{
     [self writeEntry:@"xadDidExpand: The Ad did expand"];
}

- (void)xAdDidCollapse:(XAdView *)adView{
      [self writeEntry:@"xadDidCollapse: The Ad did collapse"];
}

- (void)xAdViewDidDismissOnMemoryWarning:(XAdView *)adView{
    [self writeEntry:@"xAdViewDidDismissOnMemoryWarning Received Memory Warning"];
}


#pragma mark orientation

-(BOOL)shouldAutorotate
{
    
    [self orientationDidChange];
    
    return YES;
}
-(void) orientationDidChange
{
    CGRect bounds = [[UIScreen mainScreen] bounds]; // portrait bounds
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) && NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    
    CGRect frame = self.bannerAdViewTop.frame;
    frame.origin.x = (bounds.size.width - self.bannerAdViewTop.frame.size.width)/2;
    self.bannerAdViewTop.frame = frame;

    CGRect frame1 = self.bannerAdViewBottom.frame;
    frame1.origin.x = (bounds.size.width - self.bannerAdViewBottom.frame.size.width)/2;
    self.bannerAdViewBottom.frame = frame1;
    
    
    if(([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight|| [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft))
    {
        self.textView.frame = CGRectMake(20, 80,self.view.frame.size.width-40, 120);
    }
    else
    {
        self.textView.frame = CGRectMake(20, 80, self.view.frame.size.width-40, 250);
    }
    
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}

- (BOOL)xAdView:(XAdView *)xAdView shouldHandleClickToAction:(XClickToAction)actionType parameters:(NSDictionary *)parameters{
    myActionType = actionType;
    myParameters = parameters;
    
    BOOL returnVal = YES;
    
    switch (actionType) {

        case XClickToActionCall:
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Do you want to continue?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
            [alertView show];
            returnVal = NO;
        }
            break;
        case XClickToActionEmail:
        case XClickToActionSMS:
        case XClickToActionAppstoreItunes:
        case XClickToActionCalendar:
        default:
            break;
    }
    
    return returnVal;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == alertView.firstOtherButtonIndex){
        [self.bannerAdViewTop performClickToAction:myActionType parameters:myParameters];
    }
}

@end
