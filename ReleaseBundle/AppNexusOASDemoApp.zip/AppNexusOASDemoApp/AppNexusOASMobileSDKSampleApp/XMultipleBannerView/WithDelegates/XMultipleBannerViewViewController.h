#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface XMultipleBannerViewViewController : UIViewController <XAdViewDelegate, UIAlertViewDelegate>
@property (nonatomic, strong)IBOutlet UITextView* textView;
@end
