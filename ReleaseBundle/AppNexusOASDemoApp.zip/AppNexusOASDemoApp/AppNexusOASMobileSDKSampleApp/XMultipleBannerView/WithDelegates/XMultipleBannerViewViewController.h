#import <UIKit/UIKit.h>
#import "XAdView.h"

@interface XMultipleBannerViewViewController : UIViewController <XAdViewDelegate, UIAlertViewDelegate>
@property (nonatomic, strong)IBOutlet UITextView* textView;
@end
