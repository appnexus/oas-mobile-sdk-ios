//
//  AppNexusOASANMediatedBannerAdViewController.h
//  AppNexusOAS
//
//  Created by Nicole Hedley on 02/12/2016.
//  Copyright © 2016 24/7 Real Media. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface AppNexusOASANMediatedBannerAdViewController : UIViewController<XAdViewDelegate>

@end
