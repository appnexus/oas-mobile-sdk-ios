//
//  AppNexusOASSDK.h
//  AppNexusOAS
//
//  Created by Jose Cabal-Ugaz on 11/17/16.
//  Copyright © 2016 24/7 Real Media. All rights reserved.
//

#if USING_FRAMEWORK_BUILD

#import <AppNexusOASSDK/AppNexusOASSDK.h>

#else

#import "XGlobalConfiguration.h"
#import "XAdView.h"
#import "XAdSlotConfiguration.h"
#import "XAdInterstitialViewController.h"

#endif
