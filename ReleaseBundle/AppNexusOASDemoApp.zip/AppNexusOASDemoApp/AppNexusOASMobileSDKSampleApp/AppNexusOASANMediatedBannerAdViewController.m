//
//  AppNexusOASANMediatedBannerAdViewController.m
//  AppNexusOAS
//
//  Created by Nicole Hedley on 02/12/2016.
//  Copyright © 2016 24/7 Real Media. All rights reserved.
//

#import "AppNexusOASANMediatedBannerAdViewController.h"

@interface AppNexusOASANMediatedBannerAdViewController ()

@property (nonatomic, strong) XAdView *bannerAdView;

@end

@implementation AppNexusOASANMediatedBannerAdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    self.navigationController.navigationBarHidden = NO;
    [self initializingAd];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)initializingAd {
    /* Initialising the XAdView and fetching the ad */
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.edgesForExtendedLayout = UIRectEdgeNone; // For iOS 7 support.
    }
    
    
    self.bannerAdView = [[XAdView alloc]initWithFrame:CGRectMake(0, 0, 320,50)];
    
    self.bannerAdView.delegate = self;
    self.bannerAdView.backgroundColor = [UIColor clearColor];
    XAdSlotConfiguration *configuration = [[XAdSlotConfiguration alloc] init];
    configuration.bannerRefreshInterval = 12.0f;
    configuration.scalingAllowed = YES;
    configuration.COPPAPermissions = NO;
    [configuration setBackGroundImage:[UIImage imageNamed:@"320x50mobile_standard1.jpg"]];
    configuration.shouldOpenClickThroughURLInAppBrowser = NO;
    configuration.mediationPlacementId = @"1326299";
    configuration.mediationBannerWidth = 320.0;
    configuration.mediationBannerHeight = 50.0;
    configuration.canMediate = YES;
    self.bannerAdView.slotConfiguration = configuration;
    
    [self.view addSubview:self.bannerAdView];
    
    [self.bannerAdView loadWithDomainName:@"oasc-training7.247realmedia.com" pageName:@"demo-ads.com" adPosition:@"null"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
