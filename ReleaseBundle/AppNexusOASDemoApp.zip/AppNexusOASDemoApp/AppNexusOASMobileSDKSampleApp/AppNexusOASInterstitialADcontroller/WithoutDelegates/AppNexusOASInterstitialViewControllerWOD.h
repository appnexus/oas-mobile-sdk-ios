#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface AppNexusOASInterstitialViewControllerWOD : UIViewController<XAdInterstitialViewControllerDelegate>


@property(nonatomic, strong) NSString *adType;
@property (nonatomic, strong)XAdInterstitialViewController *interestitial;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil adType:(NSString *)currentAdType;
@end
