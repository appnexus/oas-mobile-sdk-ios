#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface AppNexusOASBannerAdViewControllerWOD : UIViewController<XAdViewDelegate>

@end
