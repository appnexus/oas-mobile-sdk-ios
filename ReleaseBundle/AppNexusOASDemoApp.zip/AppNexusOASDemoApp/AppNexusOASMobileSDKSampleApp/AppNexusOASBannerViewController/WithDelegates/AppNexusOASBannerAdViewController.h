#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface AppNexusOASBannerAdViewController : UIViewController<XAdViewDelegate, UIAlertViewDelegate>

@property (nonatomic, strong)IBOutlet UITextView* textView;

@end
