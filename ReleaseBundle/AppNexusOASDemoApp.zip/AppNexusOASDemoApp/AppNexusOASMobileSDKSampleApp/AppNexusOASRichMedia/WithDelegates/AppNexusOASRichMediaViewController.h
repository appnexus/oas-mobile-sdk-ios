
#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface AppNexusOASRichMediaViewController : UIViewController<XAdViewDelegate>

@property (nonatomic, strong)IBOutlet UITextView* textView;


@end
