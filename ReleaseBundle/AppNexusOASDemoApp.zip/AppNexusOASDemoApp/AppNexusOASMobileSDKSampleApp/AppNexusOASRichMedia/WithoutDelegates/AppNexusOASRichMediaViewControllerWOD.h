
#import <UIKit/UIKit.h>
#import "XAdView.h"
#import "XAdSlotConfiguration.h"

@interface AppNexusOASRichMediaViewControllerWOD : UIViewController<XAdViewDelegate>

@end
