
#import <UIKit/UIKit.h>
#import "AppNexusOASSDK.h"

@interface AppNexusOASRichMediaViewControllerWOD : UIViewController<XAdViewDelegate>

@end
