

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController

@property (nonatomic, strong) UITableView *adTypeTable;
@property (nonatomic, strong) NSArray *adTypeArr;
@end
