
#import "ViewController.h"
#import "AppNexusOASBannerAdViewController.h"
#import "AppNexusOASRichMediaViewController.h"
#import "XMultipleBannerViewViewController.h"
#import "AppNexusOASInterstitialAdController.h"
#import "VastAdViewController.h"
#import "AppNexusOASInterstitialViewControllerWOD.h"
#import "AppNexusOASANMediatedBannerAdViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize adTypeTable;
@synthesize adTypeArr;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:255.0/256.0 green:153.0/256.0 blue:0.0/256.0 alpha:1];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
         [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    }
    
   
    self.adTypeArr = [NSArray arrayWithObjects:@"Standard Banner Ad",@"Rich Media BannerAd",@"Multiple Banner",@"MRAID Interstitial Ad",@"VAST Interstitial Ad",@"Pre Roll Video Ad", @"AppNexus Mediated Banner Ad", nil];
  
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (section==0) {
        return 5;

    }else{
       return [self.adTypeArr count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    static NSString *CellIdentifier = @"Cell";
    if(SYSTEM_VERSION_LESS_THAN(@"6.0"))
    {
       cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }else
    {
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    }
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    [cell setSelectionStyle:UITableViewCellSelectionStyleDefault];
    // Configure the cell...
    NSString *titleString = [self.adTypeArr objectAtIndex:indexPath.row];

    cell.textLabel.text = titleString;
//    cell.textLabel.textColor =[UIColor colorWithRed:44.0/256.0 green:166.0/256.0 blue:223.0/256.0 alpha:1];
    cell.textLabel.textColor =[UIColor colorWithRed:255.0/256.0 green:153.0/256.0 blue:0.0/256.0 alpha:1];
    cell.textLabel.textAlignment = NSTextAlignmentLeft;
    
    return cell;
}



//-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
//{
//    if (section == 0) {
//        return @"Novice Developers";
//    }else{
//        return @"Power Developers";
//    }
//}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0,0,self.adTypeTable.frame.size.width,15)];
    label.font = [UIFont fontWithName:@"Helvetica" size:12];
//    label.textColor = [UIColor blackColor];
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentLeft;
//    label.backgroundColor = [UIColor colorWithRed:128.0/256.0 green:200.0/256.0 blue:235.0/256.0 alpha:1.0];
    label.backgroundColor = [UIColor colorWithRed:255.0/256.0 green:153.0/256.0 blue:0.0/256.0 alpha:1];
    if (section==0) {
        [label setText:@"Without Delegates"];
    }else{
       [label setText:@"With Delegates"];
    }
    return label;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *adDetailViewController = nil;
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    switch (indexPath.section) {
      // WITH DELEGATES
        case 1:
            switch (indexPath.row) {
                case 0:
                    if (iPadSupport)
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASBannerAd"];
                    }else
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASBannerAd"];
                    }

                    break;
                case 1:
                    if (iPadSupport)
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASRichMedia"];
                    }else
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASRichMedia"];
                    }
                    break;
                case 2:
                    if (iPadSupport)
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASMultiple"];
                    }else
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASMultiple"];
                        
                    }

                    break;
                case 3:
                    if (iPadSupport)
                    {
                        adDetailViewController = [[AppNexusOASInterstitialAdController alloc]initWithNibName:@"AppNexusOASInterstitialAdController" bundle:Nil adType:@"mraid"];
                    }else
                    {
                        adDetailViewController = [[AppNexusOASInterstitialAdController alloc]initWithNibName:@"AppNexusOASInterstitialAdController_iPad" bundle:Nil adType:@"mraid"];
                    }
                    break;
                case 4:
                    if (iPadSupport)
                    {
                        adDetailViewController = [[AppNexusOASInterstitialAdController alloc]initWithNibName:@"AppNexusOASInterstitialAdController" bundle:Nil  adType:@"vast"];
                    }else
                    {
                        adDetailViewController = [[AppNexusOASInterstitialAdController alloc]initWithNibName:@"AppNexusOASInterstitialAdController_iPad" bundle:Nil adType:@"vast"];
                    }

                    break;
                case 5:
                    if (iPadSupport)
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"VASTAdView"];
                    }else
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"VASTAdView"];
                        
                    }
                    break;
                case 6:
                    adDetailViewController = [[AppNexusOASANMediatedBannerAdViewController alloc] init];
                
                default:
                    break;
            }
            break;
            //WITHOUT DELEGATES
        case 0:
            switch (indexPath.row) {
                case 0:
                    if (iPadSupport)
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASBannerAdWOD"];
                    }else
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASBannerAdWOD"];
                    }

                    break;
                case 1:
                    if (iPadSupport)
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASRichMediaWOD"];
                    }else
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASRichMediaWOD"];
                    }

                    break;
                case 2:
                    if (iPadSupport)
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASMultipleWOD"];
                    }else
                    {
                        UIStoryboard* storyboard = [UIStoryboard storyboardWithName:@"Main-iPad" bundle:nil];
                        adDetailViewController = [storyboard instantiateViewControllerWithIdentifier:@"AppNexusOASMultipleWOD"];
                        
                    }
                    
                    break;
                case 3:
                    if (iPadSupport)
                    {
                        adDetailViewController = [[AppNexusOASInterstitialViewControllerWOD alloc]initWithNibName:@"AppNexusOASInterstitialViewControllerWOD" bundle:Nil adType:@"mraid"];
                    }else
                    {
                        adDetailViewController = [[AppNexusOASInterstitialViewControllerWOD alloc]initWithNibName:@"AppNexusOASInterstitialViewControllerWOD_iPad" bundle:Nil adType:@"mraid"];
                    }
                    break;
                case 4:
                    if (iPadSupport)
                    {
                        adDetailViewController = [[AppNexusOASInterstitialViewControllerWOD alloc]initWithNibName:@"AppNexusOASInterstitialViewControllerWOD" bundle:Nil  adType:@"vast"];
                    }else
                    {
                        adDetailViewController = [[AppNexusOASInterstitialViewControllerWOD alloc]initWithNibName:@"AppNexusOASInterstitialViewControllerWOD_iPad" bundle:Nil adType:@"vast"];
                    }
                    
                    break;
                default:
                    break;
            }
            break;
        default:
            break;
    }
    if (adDetailViewController) {
        [self.navigationController pushViewController:adDetailViewController animated:YES];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (BOOL)shouldAutorotate{
    return YES;
}

@end
