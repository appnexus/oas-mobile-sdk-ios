#import "AppNexusOASBannerAdViewControllerWOD.h"
#import "XAdView.h"
#import "XAdSlotConfiguration.h"


@interface AppNexusOASBannerAdViewControllerWOD ()


@property(nonatomic, strong)XAdView *bannerAdView;

@end

@implementation AppNexusOASBannerAdViewControllerWOD

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [self initializingAd];
    //self.navigationController.navigationBar.translucent = NO;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self orientationDidChange];
}

-(void)initializingAd
{
    /* Initialising the XAdView and fetching the ad */
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.edgesForExtendedLayout = UIRectEdgeNone; // For iOS 7 support.
    }
    
    
    self.bannerAdView = [[XAdView alloc]initWithFrame:CGRectMake(0, 0, 320,50)];
    
    self.bannerAdView.delegate = self;
    self.bannerAdView.backgroundColor = [UIColor clearColor];
    XAdSlotConfiguration *configuration = [[XAdSlotConfiguration alloc] init];
    configuration.bannerRefreshInterval = 12.0f;
    configuration.scalingAllowed = YES;
    configuration.COPPAPermissions = NO;
    [configuration setBackGroundImage:[UIImage imageNamed:@"320x50mobile_standard1.jpg"]];
    configuration.shouldOpenClickThroughURLInAppBrowser = NO;
    
    // Configure mediation
    configuration.mediationPlacementId = @"2054679";
    configuration.mediationBannerWidth = 320.0;
    configuration.mediationBannerHeight = 50.0;
    configuration.canMediate = YES;
    
    self.bannerAdView.slotConfiguration = configuration;
    
    [self.view addSubview:self.bannerAdView];
    
     [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"demo_standardbanner" adPosition:@"Bottom" keywords:nil queryString:nil];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)dealloc{
    
    self.bannerAdView = nil;
}

-(BOOL)shouldAutorotate
{
    [self orientationDidChange];
    return YES;
}
-(void) orientationDidChange
{
    CGRect bounds = [[UIScreen mainScreen] bounds]; // portrait bounds
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) && NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    
    CGRect frame = self.bannerAdView.frame;
    frame.origin.x = (bounds.size.width - self.bannerAdView.frame.size.width)/2;
    self.bannerAdView.frame = frame;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}


@end
