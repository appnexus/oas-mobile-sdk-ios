#import <UIKit/UIKit.h>
#import "XAdView.h"

@interface AppNexusOASBannerAdViewControllerWOD : UIViewController<XAdViewDelegate>

@end
