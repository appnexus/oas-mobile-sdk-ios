#import <UIKit/UIKit.h>
#import "XAdView.h"
#import "XAdSlotConfiguration.h"

@interface AppNexusOASBannerAdViewController : UIViewController<XAdViewDelegate, UIAlertViewDelegate>

@property (nonatomic, strong)IBOutlet UITextView* textView;

@end
