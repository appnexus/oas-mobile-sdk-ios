#import "AppNexusOASBannerAdViewController.h"


@interface AppNexusOASBannerAdViewController (){
    NSDictionary *myParameters;
    XClickToAction myActionType;
}

@property(nonatomic,strong)IBOutlet XAdView *bannerAdView;
@property(nonatomic,strong) XAdSlotConfiguration *configuration;

@end

@implementation AppNexusOASBannerAdViewController
@synthesize textView,bannerAdView,configuration;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
       [super viewDidLoad];
    [self writeEntry:@"viewDidLoad"];

     [self initializingAd];
    self.navigationController.navigationBarHidden = NO;
   
  
    
}

-(void)viewWillAppear:(BOOL)animated{
    [self writeEntry:@"viewWillAppear"];
    [super viewWillAppear:animated];
    
    [self orientationDidChange];
//    [self initializingAd];
        /* Initialising the XAdView and fetching the ad */
    }

-(void)initializingAd
{
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.edgesForExtendedLayout = UIRectEdgeNone; // For iOS 7 support.
    }
    
    
  self.bannerAdView = [[XAdView alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
   
    
    self.bannerAdView.delegate = self;
    
    //Configure
    configuration = [[XAdSlotConfiguration alloc] init];
    configuration.bannerRefreshInterval = 0.0f;
    configuration.scalingAllowed = YES;
    configuration.maintainAspectRatio = NO;
    configuration.RTBRequired = NO;
    configuration.COPPAPermissions = NO;
    configuration.shouldOpenClickThroughURLInAppBrowser = NO;
    
    // Configure mediation
    configuration.mediationPlacementId = @"2054679";
    configuration.mediationBannerWidth = 320.0;
    configuration.mediationBannerHeight = 50.0;
    configuration.canMediate = YES;
    
    // Set placeholder image
    [configuration setBackGroundImage:[UIImage imageNamed:@"320x50mobile_standard1.jpg"]];
    self.bannerAdView.slotConfiguration = configuration;
    
    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"demo_standardbanner" adPosition:@"Bottomx"];
    
    [self.view addSubview:self.bannerAdView];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)dealloc{

    self.bannerAdView = nil;
}

- (void)writeEntry:(NSString*)entry
{
    NSString* text = [self.textView.text stringByAppendingFormat:@"\n%@\n--", entry];
    self.textView.text = text;
    
    [self.textView scrollRangeToVisible:NSMakeRange(text.length+5000, 0)];
}
#pragma mark XAdViewDelegates

-(void)xAdWillLoad:(XAdView *)adView
{
    
}

-(void)xAdViewDidLoad:(XAdView *)adView
{
    [self writeEntry:@"xAdViewDidLoad: The Ad was loaded successfully"];
    NSLog(@"The ad was loaded successfully");

}

- (void)xAdView:(XAdView *)xAdView didFailWithError:(NSError *)error{
    [self writeEntry:[NSString stringWithFormat:@"xAdViewDidFailWithError: %@", [error localizedDescription]]];
}

-(void)xAdViewDidReceiveNoAd:(XAdView *)adView
{
    [self writeEntry:@"xAdViewDidReceiveNoAd: No ad was received from server"];
}

-(void)didClickOnAd:(XAdView *)adView{
    [self writeEntry:@"xAdView: didClickOnAd"];
}


-(void)xAdViewWillOpenInInAppBrowser:(XAdView *)adView{
    [self writeEntry:@"xAdViewWillOpenInInAppBrowser The Ad opened in Internal Browser"];
}

-(void)xAdViewWllLeaveApplication:(XAdView *)adView{
    [self writeEntry:@"xAdViewWllLeaveApplication The Ad opened in External Browser"];
}
-(void)xAdViewWillCloseInAppBrowser:(XAdView *)adView{
    [self writeEntry:@"xAdViewWillCloseInAppBrowser  InApp browser closed"];
}

- (void)xAdViewDidDismissOnMemoryWarning:(XAdView *)adView{

    [self writeEntry:@"xAdViewDidDismissOnMemoryWarning Received Memory Warning"];
}

#pragma mark orientation

-(BOOL)shouldAutorotate
{
    [self orientationDidChange];
    return YES;
}

-(void) orientationDidChange
{
    CGRect bounds = [[UIScreen mainScreen] bounds]; // portrait bounds
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) && NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    
    CGRect frame = self.bannerAdView.frame;
    frame.origin.x = (bounds.size.width - self.bannerAdView.frame.size.width)/2;
    self.bannerAdView.frame = frame;
    
    if(([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight|| [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft))
    {
        self.textView.frame = CGRectMake(20, 100,self.view.frame.size.width-40, 150);
    }
    else
    {
        self.textView.frame = CGRectMake(20, 80, self.view.frame.size.width-40, 250);
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}

- (BOOL)xAdView:(XAdView *)xAdView shouldHandleClickToAction:(XClickToAction)actionType parameters:(NSDictionary *)parameters{
    myActionType = actionType;
    myParameters = parameters;
    
    BOOL returnVal = YES;
    
    switch (actionType) {
            
//        case XClickToActionOpenBrowser:
//        {
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"<Alert message for ""open browser"" goes here?>" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
//            [alertView show];
//            returnVal = NO;
//        }
//            break;
        case XClickToActionCall:
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"<Alert message for ""call"" goes here?>" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
            [alertView show];
            returnVal = NO;
        }
            break;
        case XClickToActionEmail:
        case XClickToActionSMS:
        case XClickToActionAppstoreItunes:
        case XClickToActionCalendar:
        default:
            break;
    }
    
    return returnVal;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == alertView.firstOtherButtonIndex){
        [self.bannerAdView performClickToAction:myActionType parameters:myParameters];
    }
}

@end
