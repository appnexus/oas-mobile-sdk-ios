#import <UIKit/UIKit.h>
#import "XAdInterstitialViewController.h"

@interface AppNexusOASInterstitialAdController : UIViewController<XAdInterstitialViewControllerDelegate>


@property(nonatomic, strong) NSString *adType;
@property (nonatomic, strong)XAdInterstitialViewController *interestitial;
@property (nonatomic, strong)IBOutlet UITextView* textView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil adType:(NSString *)currentAdType;
@end
