#import "AppNexusOASInterstitialAdController.h"
#import "XAdSlotConfiguration.h"
#import "XAdView.h"

@interface AppNexusOASInterstitialAdController (){
    NSDictionary *myParameters;
    XClickToAction myActionType;
}


@end

@implementation AppNexusOASInterstitialAdController
@synthesize adType;
@synthesize interestitial;
@synthesize textView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil adType:(NSString *)currentAdType
{
    self = [self initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.adType = currentAdType;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    interestitial = [[XAdInterstitialViewController alloc] init];
    self.navigationController.navigationBarHidden = NO;
   [self presentInterstitialAd];
    self.textView.backgroundColor = self.view.backgroundColor;
    self.textView.editable = NO;
    self.textView.scrollEnabled = YES;
    
}

-(void)dealloc{
    interestitial = nil;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
        [self orientationDidChange];
}
-(void)viewWillDisappear:(BOOL)animated{
    
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:YES];
}
- (void)writeEntry:(NSString*)entry
{
    NSString* text = [self.textView.text stringByAppendingFormat:@"\n%@\n--", entry];
    self.textView.text = text;
    
    [self.textView scrollRangeToVisible:NSMakeRange(text.length, 0)];

}

#pragma mark - Other Methods

-(void)presentInterstitialAd
{
    //interestitial = [[XAdInterstitialViewController alloc] init];
    
    interestitial.delegate = self;
    XAdSlotConfiguration *configuration = [[XAdSlotConfiguration alloc] init];
    configuration.bannerRefreshInterval = 0.0f;
    configuration.RTBRequired = NO;
    configuration.COPPAPermissions = NO;
    configuration.shouldOpenClickThroughURLInAppBrowser = NO;
    
    //Configure Mediation
    configuration.canMediate = YES;
    configuration.mediationPlacementId = @"2054679";
    
    interestitial.slotConfiguration = configuration;
    
    if ([self.adType isEqualToString:@"mraid"])
    {
        [interestitial loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"Android_Mob_Interstitial_Bursting_Pipe.com" adPosition:@"Bottom"];

    }
    else if([self.adType isEqualToString:@"vast"])
    {
        [interestitial loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"MSDK-Vast-Renditions" adPosition:@"x25"];
    }
}


#pragma mark
#pragma mark - InterstitialView Delegate Methods

-(void)xAdInterstitialDidLoad:(XAdInterstitialViewController *)interstitialAdViewController{
    
    [self writeEntry:@"xAdInterstitialDidLoad The ad loaded Successfully"];
    
    if (interstitialAdViewController) {
        [self.navigationController presentViewController:interestitial animated:YES completion:nil];
    }
    
}

-(void)xAdInterstitial:(XAdInterstitialViewController *)interstitialAdViewController didFailWithError:(NSError *)error{
    
    [self writeEntry:[NSString stringWithFormat:@"xAdInterstitial:didFailWithError - %@", [error localizedDescription]]];
}

-(void)xAdInterstitialDismissed:(XAdInterstitialViewController *)interstitialAdViewController
{
    [self writeEntry:@"xAdInterstitialDismissed: Interstitial Ad Dismissed"];

}

- (void)xAdInterstitialDidClick:(XAdInterstitialViewController *)interstitialAdViewController{
    [self writeEntry:@"xAdInterstitialDidClick: Interstitial Ad Clicked"];
}

- (void)xAdInterstitialDidDismissOnMemoryWarning:(XAdInterstitialViewController *)interstitialAdViewController{
   
    [self writeEntry:@"xAdInterstitialDidDismissOnMemoryWarning Received Memory Warning"];
}

-(void)xad:(XAdView *)adView{
    [self writeEntry:@"xAdView: didClickOnAd"];
}

-(void)dismissAd
{
    
}
#pragma mark Video Delegates

-(void)xAdInterstitial:(XAdInterstitialViewController *)interstitialAdViewController didPauseVideo:(NSTimeInterval)currentTime
{
    [self writeEntry:@"xAdinterstitial: didPauseVideo"];
    NSLog(@"xAdinterstitial: didPauseVideo");
}
-(void)xAdInterstitial:(XAdInterstitialViewController *)interstitialAdViewController didFinsihQuartile:(XVideoQuartile)quartile
{
    if (quartile==XVideoQuartileFirst) {
         NSLog(@"xAdInterstitial didFinishQuartile: First");
        [self writeEntry:@"xAdinterstitial: didFinishQuartile: First"];
    }else if (quartile == XVideoQuartileMidPoint)
    {   NSLog(@"xAdInterstitial didFinishQuartile: Midpoint");
        [self writeEntry:@"xAdinterstitial: didFinishQuartile: Midpoint"];
    }else{
         NSLog(@"xAdInterstitial didFinishQuartile: Third");
        [self writeEntry:@"xAdinterstitial: didFinishQuartile: Third"];
    }
    
    NSLog(@"xAdInterstitial didFinishQuartile");
}
-(void)xAdInterstitial:(XAdInterstitialViewController *)interstitialAdViewController didResume:(NSTimeInterval)currentTime
{
    [self writeEntry:@"xAdinterstitial: didResumeVideo"];
    NSLog(@"xAdInterstitial didResumeVideo");
}
-(void)xAdInterstitial:(XAdInterstitialViewController *)interstitialAdViewController didSkipVideo:(NSTimeInterval)skipTime
{
    NSLog(@"didSkipVideo");
}

-(void)xAdInterstitialDidExitFullScreen:(XAdInterstitialViewController *)interstitialAdViewController
{
    [self writeEntry:@"xAdinterstitial : ExitFullScreen"];
}

-(void)xAdInterstitialDidEnterFullScreen:(XAdInterstitialViewController *)interstitialAdViewController
{
    [self writeEntry:@"xAdInterstitial : EnterFullScreen"];
}


- (BOOL)xAdInterstitialViewController:(XAdInterstitialViewController *)xAdInterstitialViewController shouldHandleClickToAction:(XClickToAction)actionType parameters:(NSDictionary *) parameters{
    
    myActionType = actionType;
    myParameters = parameters;
    
    BOOL returnVal = YES;

    switch (actionType) {
            
//        case XClickToActionOpenBrowser:
//        {
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"<Alert message for ""Open Browser"" goes here>" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
//            [alertView show];
//            returnVal = NO;
//        }
//            break;
        case XClickToActionCall:
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"<Alert message for ""Call"" goes here>" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
            [alertView show];

            returnVal = NO;
        }
            break;
        case XClickToActionEmail:
        case XClickToActionSMS:
        case XClickToActionAppstoreItunes:
        case XClickToActionCalendar:
        default:
            break;
    }
    
    return returnVal;
    
}

#pragma mark - UIAlertViewDelegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == alertView.cancelButtonIndex)
    {
        //Do nothing
    }
    else if (buttonIndex == alertView.firstOtherButtonIndex)
    {
        [self.interestitial performClickToAction:myActionType parameters:myParameters];
    }
}


#pragma mark orientation


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}

-(void) orientationDidChange
{
    if(([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight|| [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft))
        self.textView.frame = CGRectMake(20, 80, self.view.frame.size.width-40, 150);
    else
        self.textView.frame = CGRectMake(20, 80, self.view.frame.size.width-40, 250);
}

-(BOOL)shouldAutorotate
{
    [self orientationDidChange];
    return YES;
}

@end
