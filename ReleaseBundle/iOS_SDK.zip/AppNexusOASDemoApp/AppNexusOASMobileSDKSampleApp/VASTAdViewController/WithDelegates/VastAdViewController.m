

#import <Foundation/Foundation.h>
#import "VastAdViewController.h"
#import "XAdView.h"
#import "XAdSlotConfiguration.h"


@interface VastAdViewController ()
{

    XAdView *adview;
}
@end

@implementation VastAdViewController
@synthesize moviePlayerControllerInstance;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    
    [self presentVastAd];
    
}
-(void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    
    if(([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight|| [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft))
    {
        [moviePlayerControllerInstance.view setFrame:CGRectMake(0, height/6, self.view.frame.size.width, self.view.frame.size.height/2)];
    }
    else
    {
        [moviePlayerControllerInstance.view setFrame:CGRectMake(0, height/3, self.view.frame.size.width, self.view.frame.size.height/2.8)];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)presentVastAd{
    
    NSString *filepath   =   [[NSBundle mainBundle] pathForResource:@"big-buck-bunny-clip" ofType:@"m4v"];
    NSURL    *fileURL    =   [NSURL fileURLWithPath:filepath];
    moviePlayerControllerInstance = [[MPMoviePlayerController alloc] initWithContentURL:fileURL];
	
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(moviePlaybackComplete:)
												 name:MPMoviePlayerPlaybackDidFinishNotification
											   object:moviePlayerControllerInstance];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(moviePlayerScalingModeChanged:)
												 name:MPMoviePlayerScalingModeDidChangeNotification

											   object:moviePlayerControllerInstance];
    
    [self.view addSubview:moviePlayerControllerInstance.view];
    
    adview = [[XAdView alloc] init];
    XAdSlotConfiguration *configuration = [[XAdSlotConfiguration alloc] init];
    configuration.shouldOpenClickThroughURLInAppBrowser = NO;
    configuration.RTBRequired = NO;
    configuration.dismissVideoOnClickThrough = NO;
    configuration.canMediate = YES;
    configuration.countdownTimerPosition = XCountdownTimerPositionTopCenter;
    [configuration setSkipOffsetTime:10];
    [configuration setSkipOffsetType:XSkipOffsetRelative];
    adview.slotConfiguration = configuration;
    adview.moviePlayerInstance = moviePlayerControllerInstance;
    adview.delegate = self;
    
    [adview loadWithDomainName:@"openad.tf1.fr" pageName:@"vast_preroll" adPosition:@"Frame1"];

}

- (void)moviePlayerScalingModeChanged:(NSNotification *)notification
{
}


- (void)moviePlaybackComplete:(NSNotification *)notification
{
}


-(void)dismissAd
{
    
}

#pragma mark - XAdViewDelegate Methods

-(void)xAdViewDidDismissOnMemoryWarning:(XAdView *)adView{
    [moviePlayerControllerInstance play];
}


-(void)xAdView:(XAdView *)xadView prerollDidFinishWithPlayer:(MPMoviePlayerController *)moviePlayerController
{
    NSLog(@"Ad finished! Playing my video!!");
    [moviePlayerController play];
}
-(void)xAdView:(XAdView *)xAdView didSkipVideo:(NSTimeInterval)skipTime

{
    NSLog(@"xAdview didSkipVideo");
}
-(void)xAdView:(XAdView *)xAdView didFailWithError:(NSError *)error
{
    [moviePlayerControllerInstance play];
}
-(void)didClickOnAd:(XAdView *)adView{
    NSLog(@"xAdView did click on ad");
}
#pragma mark Video Delegates
-(void)xAdView:(XAdView *)xAdView didResume:(NSTimeInterval)currentTime
{
    NSLog(@"XAdView: ResumeVideo");
}

-(void)xAdView:(XAdView *)xAdView didPauseVideo:(NSTimeInterval)currentTime
{
    NSLog(@"XadView: didPauseVideo");
}

-(void)xAdViewDidEnterFullScreen:(XAdView *)xAdView
{
    NSLog(@"Preroll Enter FUll screen");
}
-(void)xAdViewDidExitFullScreen:(XAdView *)xAdView
{
    NSLog(@"Preroll exit full ");
}
-(void)xAdView:(XAdView *)xAdView didFinishQuartile:(XVideoQuartile)quartile
{
    NSLog(@"xadview Quartile");
}
-(void)xAdViewDidRewind:(XAdView *)xAdView
{
    NSLog(@"xadView Rewind the video");
}

#pragma mark Delegates end

-(void) dealloc
{
    [moviePlayerControllerInstance setContentURL:nil];
    [moviePlayerControllerInstance stop];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:moviePlayerControllerInstance];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerScalingModeDidChangeNotification object:moviePlayerControllerInstance];
    moviePlayerControllerInstance = nil;
}
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
}






-(BOOL)shouldAutorotate
{
  
    [self orientationDidChange];
    return YES;
}

-(void) orientationDidChange
{
    CGRect bounds = [[UIScreen mainScreen] bounds]; // portrait bounds
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) && NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    
    CGRect frame = self.view.frame;
    frame.origin.x = (bounds.size.width - self.view.frame.size.width)/2;
    self.view.frame = frame;

    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    
    if(([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight|| [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft))
    {
          [moviePlayerControllerInstance.view setFrame:CGRectMake(0, height/6, self.view.frame.size.width, self.view.frame.size.width/2.8)];
    }
    else
    {
        [moviePlayerControllerInstance.view setFrame:CGRectMake(0, height/3, self.view.frame.size.width, self.view.frame.size.height/2.8)];
    }
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}

@end
