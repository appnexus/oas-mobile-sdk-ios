

#import <UIKit/UIKit.h>

@interface UINavigationController (Rotation_IOS6)

@end
