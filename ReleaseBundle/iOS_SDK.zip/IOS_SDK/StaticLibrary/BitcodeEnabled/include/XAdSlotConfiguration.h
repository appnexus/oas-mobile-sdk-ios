//
//  XAdSlotConfiguration.h
//  AppNexusOASSDK
//
//  Created by Developer on 1/23/14.
//  Copyright (c) 2014 AppNexusOAS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    XCountdownTimerPositionTopRight = 0,
    XCountdownTimerPositionTopCenter,
    XCountdownTimerPositionTopLeft,
    XCountdownTimerPositionBottomLeft,
    XCountdownTimerPositionBottomCenter,
    XCountdownTimerPositionBottomRight
} XCountdownTimerPosition;

typedef enum : NSInteger {
    XSkipOffsetAbsolute = 0,
    XSkipOffsetRelative
} XSkipOffsetType;

@interface XAdSlotConfiguration : NSObject


/**
 *  Sets the banner refresh interval for the ads displayed.
 */
@property (nonatomic) float bannerRefreshInterval;

/**
 *  Set the flag to show companion ads
 */
@property (nonatomic) BOOL canShowCompanionAd;

/**
 *  Mainatin aspect ratio
 */
@property (nonatomic) BOOL maintainAspectRatio;

/**
 *  Set whether scaling is allowed
 */
@property (nonatomic) BOOL scalingAllowed;

/**
 *  Set placeholder image
 */
@property (nonatomic,strong) UIImage *backGroundImage;

/**
 *  Permission for accessing geo based location service to extend the ad server capabilities
 */
@property (nonatomic) BOOL accessToGeoLocation;

/**
 *  This method will set the permissions as true or false for COPPA.
 */
@property (nonatomic) BOOL COPPAPermissions;

/**
 *  This will return the value for RTB response
 */
@property (nonatomic) BOOL RTBRequired;

/**
 *  This will return the value for whether to show the clickthrough inline or in a separate browser.
 */
@property (nonatomic) BOOL shouldOpenClickThroughURLInAppBrowser;

/**
 *  Flag to enable or disable the mediation network at slot level
 */
@property (nonatomic) int canMediate;

/**
 *  placementId as required by the mediation networks. This is required for mediation to work.
 */
@property (nonatomic, strong) NSString *mediationPlacementId;

/**
 *  Width of the banner for mediation ads. This is required to show banner ads through mediation. Not required by interstitial ads.
 */
@property (nonatomic) float mediationBannerWidth;

/**
 *  Height of the banner for mediation ads. This is required to show banner ads through mediation. Not required by interstitial ads.
 */
@property (nonatomic) float mediationBannerHeight;

/**
 *  Optional, to show ads based on the age of the user.
 */
@property (nonatomic) int mediationTargetedAge;

/**
 *  Optional, to show ads based on the user gender.
 */
@property (nonatomic) int mediationTargetedGender;

/**
 *  Optional, This is a key, value pair to show ads based on the keywords provided.
 */
@property (nonatomic, strong) NSDictionary *mediationTargetedKeywords;

/**
 *  Optional, if provided, will display the countdown timer at that position on the ad.
 */
@property (nonatomic) NSUInteger countdownTimerPosition;

/**
 *  Optional, takes a BOOL values. If set to true the video ad will be dismissed on click through, else it will retain it's state and position unless it is hibernated for over 30 seconds. Default is set to YES.
 */
@property (nonatomic) BOOL dismissVideoOnClickThrough;

/**
 *  Optional, takes an integer values. the skip button will appear after these many seconds. This will be effective only when creative does not provide a skipoffset value.
 */
@property (nonatomic) NSInteger skipOffsetTime;

/**
 *  Optional, takes an enum values. defines the type of offset. XSkipOffsetAbsolute defines absolute (in seconds) and XSkipOffsetRelative defines offset in percentage
 */
@property (nonatomic) XSkipOffsetType skipOffsetType;

/**
 * Optional, set this value to enable Hybrid Ad Request. By enabling this flag, the original ad response with the integrated impression URL will be returned to the publisher and SDK would terminate the flow and will not send any delegates (other than  back to the publishers.
 */

@property (nonatomic) BOOL instreamHTMLAd;

@end
