//


//  XAdInterstitialView.h
//  AppNexusOASSDK
//
//  Created by Developer on 1/23/14.
//  Copyright (c) 2014 AppNexusOAS. All rights reserved.
//


#import "XAdView.h"
@class XAdSlotConfiguration;
@protocol XAdInterstitialViewControllerDelegate;

@interface XAdInterstitialViewController : UIViewController

/**
 *  @property delegate
 *  @brief The receiver's delegate
 *   The delegate is sent messages when ad is loading. See XAdInterstitialViewControllerDelegate Protocol Reference for the optional methods this delegate may implement.
 */
@property (nonatomic, weak) id<XAdInterstitialViewControllerDelegate> delegate;

/**
 *  @property slotConfiguration
 *  @brief The XAdSlotConfiguration instance for ad configuration
 */
@property (nonatomic, strong) XAdSlotConfiguration *slotConfiguration;

@property (nonatomic, readwrite) BOOL isVastInterestitial;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name, ad position, postal code and query string.
 *  
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 *  @param keywords     Comma separated values to filter the ads based on these keywords
 *  @param queryString  Key value pair for additional filtering of Ads
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition keywords:(NSString *)keywords queryString:(NSString *)queryString;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name, ad position, postal code and query string.
 *
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 *  @param queryString  Key value pair for additional filtering of Ads
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition queryString:(NSString *)queryString;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name and ad position.
 *
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 *  @param keywords     Comma separated values to filter the ads based on these keywords
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition keywords:(NSString *)keywords;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name and ad position.
 *
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition;

/**
 * Returns the current SDK version
 */
+(NSString *)appNexusOASSDKVersion;

/**
 *  Perform click to action
 *
 *  @param actionType The type of click to action that is requested
 *  @param parameters The key value pair used to create command URL or calendar event
 */
- (void) performClickToAction:(XClickToAction)actionType parameters:(NSDictionary *) parameters;
@end

@protocol XAdInterstitialViewControllerDelegate <NSObject>

@optional

/**
 * Sent when the interstitial is dismissed.
 */
-(void)xAdInterstitialDismissed:(XAdInterstitialViewController *)interstitialAdViewController;

/**
 * Sent when an ad view successfully loads an ad.
 *
 * Your implementation can add a view in hierarchy if you have not added it already
 * @param interstitialAdViewController The ad view controller sending the message.
 */
-(void)xAdInterstitialDidLoad:(XAdInterstitialViewController *)interstitialAdViewController;

/**
 * Sent when an ad view fails to load an ad.
 *
 * If you have already presented the ad viewcontroller, you must dismiss the viewcontroller on this delegate call to avoid displaying of blank ads
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 * @param error            An NSError object describing the error that occurred
 */
-(void)xAdInterstitial:(XAdInterstitialViewController *)interstitialAdViewController didFailWithError:(NSError *)error;


///**
// * Sent when server returns a blank ad.
// 
// * @param interstitialAdViewController The ad view controller sending the message.
// */
//-(void)xAdInterstitialDidReceiveNoAd:(XAdInterstitialViewController *)interstitialAdViewController;


/**
 * Sent when an interstitial ad is clicked
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 */
-(void)xAdInterstitialDidClick:(XAdInterstitialViewController *)interstitialAdViewController;

/**
 *  Sent when XAdView has cleared the memory.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 */
-(void)xAdInterstitialDidDismissOnMemoryWarning:(XAdInterstitialViewController *)interstitialAdViewController;

/**
 *  Sent when interstitial video is paused.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 * @param currentTime the time at which the video is paused.
 */

-(void)xAdInterstitial :(XAdInterstitialViewController*)interstitialAdViewController didPauseVideo :(NSTimeInterval)currentTime;
/**
 *  Sent when interstitial video is resumed.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 * @param currentTime the time at which the video is resumed.
 */
-(void)xAdInterstitial :(XAdInterstitialViewController*)interstitialAdViewController didResume :(NSTimeInterval)currentTime;
/**
 *  Sent when interstitial video is skipped.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 * @param skipTime the time at which the video was skipped.
 */
-(void)xAdInterstitial :(XAdInterstitialViewController*)interstitialAdViewController didSkipVideo :(NSTimeInterval)skipTime;
/**
 *  Sent when interstitial video finishes a quartile.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 * @param quartile the quartile which video has shown the user.
 */
-(void)xAdInterstitial:(XAdInterstitialViewController*)interstitialAdViewController didFinishQuartile:(XVideoQuartile)quartile;
/**
 *  Sent when interstitial video enters full screen.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 */
-(void)xAdInterstitialDidEnterFullScreen :(XAdInterstitialViewController*)interstitialAdViewController;
/**
 *  Sent when interstitial video exits full screen.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 */
-(void)xAdInterstitialDidExitFullScreen :(XAdInterstitialViewController*)interstitialAdViewController;
/**
 *  Sent when interstitial video is rewound.
 *
 * @param interstitialAdViewController The ad view controller sending the message.
 */
-(void)xAdInterstitialDidRewind:(XAdInterstitialViewController*)interstitialAdViewController;


/**
 *  Sent when ad leaves the application to open a url in external browser
 *
 *  @param interstitialAdViewController the expanded instance of the XAdInterstitialViewController
 */
-(void)xAdInterstitialWillLeaveApplication:(XAdInterstitialViewController*)interstitialAdViewController;

/**
 *  Sent when the inapp browser is presented
 */
-(void)xAdInterstitialWillOpenInInAppBrowser:(XAdInterstitialViewController*)interstitialAdViewController;
/**
 *  Sent when the inapp browser is closed
 *
 *  @param interstitialAdViewController the instance of XAdInterstitialViewController
 */
-(void)xAdInterstitialWillCloseInAppBrowser:(XAdInterstitialViewController*)interstitialAdViewController;

/**
 *  Asks the delegate if webview should display ad after webview finish rendering.
 *
 *  @param xAdInterstitialViewController the instance of XAdInterstitialViewController
 *  @param webView the instance of UIWebView
 *
 */
-(BOOL)xAdInterstitialViewController:(XAdInterstitialViewController*)xAdInterstitialViewController shouldDisplayAdOnWebViewFinishRender:(UIWebView *)webView;

/**
 *  Sent before a xadview perform click to action
 *
 *  @param xAdInterstitialViewController    XAdInterstitialViewController that is about to handle the click to action
 *  @param actionType The type of click to action that is requested
 *  @param parameters The key value pair used to create command URL or calendar event
 *
 *  @return YES if the xAdInterstitialViewController should handle click to action; otherwise, NO.
 */
- (BOOL)xAdInterstitialViewController:(XAdInterstitialViewController *)xAdInterstitialViewController shouldHandleClickToAction:(XClickToAction)actionType parameters:(NSDictionary *) parameters;

/**
 *  Sent before a xadview handles the custom URL
 *
 *  @param xAdInterstitialViewController    XAdInterstitialViewController that is about to handle the click to action
 *  @param url      url to be handled by the publisher
 *
 *  @return YES if the xadInterstitialViewController should handle click to action; otherwise, NO.
 */
- (void)xAdInterstitialViewController:(XAdInterstitialViewController *)xAdInterstitialViewController shouldHandleCustomURL:(NSURL *)url;

/**
 * Sent when instreamHTMLAd = YES
 *
 *  @param xAdInterstitialViewController   XAdInterstitialViewController that is about to handle the InStreamHTMLAd Request
 *  @param htmlString   raw HTML string embedded with impression image.
 *
 *  @return void
 */

- (void)xAdInterstitialViewController:(XAdInterstitialViewController *)xAdInterstitialViewController handleInstreamHTMLAdRequest:(NSString *)htmlString;

@end
