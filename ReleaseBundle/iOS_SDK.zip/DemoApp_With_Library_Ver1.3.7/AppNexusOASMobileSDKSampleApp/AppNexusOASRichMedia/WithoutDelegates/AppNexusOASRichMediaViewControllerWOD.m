
#import "AppNexusOASRichMediaViewControllerWOD.h"

@interface AppNexusOASRichMediaViewControllerWOD ()

@property(nonatomic,strong)XAdView *bannerAdView;

@end


@implementation AppNexusOASRichMediaViewControllerWOD

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [self initializingAd];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self intializingFrame];
    [self orientationDidChange];
}

-(void)intializingFrame
{
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.edgesForExtendedLayout = UIRectEdgeNone; // For iOS 7 support.
    }
    /* Initialising the XAdView and fetching the ad */
    self.bannerAdView.frame = CGRectMake(0, 0, 320, 50);
    self.bannerAdView.delegate = self;
    [self.view addSubview:self.bannerAdView];
    
}
-(void)initializingAd
{
    /* Initialising the XAdView and fetching the ad */
    self.bannerAdView = [[XAdView alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
    XAdSlotConfiguration *configuration = [XAdSlotConfiguration new];
    [configuration setBackGroundImage:[UIImage imageNamed:@"320x50mobile_standard1.jpg"]];
    configuration.bannerRefreshInterval = 12.0f;
    self.bannerAdView.slotConfiguration = configuration;
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com"  pageName:@"www.celtraad.com" adPosition:@"@Bottom"];
    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"MSDK-Celtra-MRAID2-ExpandableBanner-a15e2c7e" adPosition:@"x25" keywords:nil queryString:nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark orientation
-(BOOL)shouldAutorotate
{
    [self orientationDidChange];
    
    return YES;
}

-(void) orientationDidChange
{
    
    CGRect bounds = [[UIScreen mainScreen] bounds]; // portrait bounds
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) && NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    
    CGRect frame = self.bannerAdView.frame;
    frame.origin.x = (bounds.size.width - self.bannerAdView.frame.size.width)/2;
    self.bannerAdView.frame = frame;

}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}

@end
