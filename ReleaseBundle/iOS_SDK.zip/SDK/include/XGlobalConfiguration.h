//
//  XGlobalConfiguration.h
//  AppNexusOAS
//
//  Created by Developer on 3/9/15.
//  Copyright (c) 2015 24/7 Real Media. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@interface XGlobalConfiguration : NSObject

/**
 @property canMediate
 @brief true = allow mediation at application level, false = do not allow mediation at application level
 **/
@property (nonatomic) int canMediate;

/**
 @property enableDebugLogs
 @brief enable it to see the detailed logs from the SDK
 **/
@property (nonatomic) bool enableDebugLogs;

/**
 @property mediationTargetedLocation
 @brief required to deliver the mediated ads based on location
 **/
@property (nonatomic, strong) CLLocation *mediationTargetedLocation;

/**
 @method sharedInstance
 @brief provides shared instance of the class object
 **/
+ (XGlobalConfiguration *) sharedInstance;

@end
