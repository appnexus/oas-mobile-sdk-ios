//
//  XAdSlotConfiguration.h
//  AppNexusOASSDK
//
//  Created by Developer on 1/23/14.
//  Copyright (c) 2014 AppNexusOAS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface XAdSlotConfiguration : NSObject


/**
 *  Sets the banner refresh interval for the ads displayed.
 */
@property (nonatomic) float bannerRefreshInterval;

/**
 *  Set the flag to show companion ads
 */
@property (nonatomic) BOOL canShowCompanionAd;

/**
 *  Mainatin aspect ratio
 */
@property (nonatomic) BOOL maintainAspectRatio;

/**
 *  Set whether scaling is allowed
 */
@property (nonatomic) BOOL scalingAllowed;

/**
 *  Set placeholder image
 */
@property (nonatomic,strong) UIImage *backGroundImage;

/**
 *  Permission for accessing geo based location service to extend the ad server capabilities
 */
@property (nonatomic) BOOL accessToGeoLocation;

/**
 *  This method will set the permissions as true or false for COPPA.
 */
@property (nonatomic) BOOL COPPAPermissions;

/**
 *  This will return the value for RTB response
 */
@property (nonatomic) BOOL RTBRequired;

/**
 *  This will return the value for whether to show the clickthrough inline or in a separate browser.
 */
@property (nonatomic) BOOL shouldOpenClickThroughURLInAppBrowser;

@property (nonatomic) int canMediate;

@property (nonatomic, strong) NSString *mediationPlacementId;

@property (nonatomic) float mediationBannerWidth;

@property (nonatomic) float mediationBannerHeight;

@property (nonatomic) int mediationTargetedAge;

@property (nonatomic) int mediationTargetedGender;

@property (nonatomic, strong) NSDictionary *mediationTargetedKeywords;

@end
