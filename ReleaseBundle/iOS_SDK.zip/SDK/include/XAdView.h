//
//  XAdView.h
//  AppNexusOASSDK
//
//  Created by Developer on 1/23/14.
//  Copyright (c) 2014 AppNexusOAS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <EventKit/EventKit.h>
#import <EventKitUI/EventKitUI.h>

typedef  enum
{
    XVideoQuartileFirst =0,
    XVideoQuartileMidPoint,
    XVideoQuartileThird
}XVideoQuartile;

typedef enum : NSUInteger {
    
    XClickToActionNone = 0,
    XClickToActionCall,
    XClickToActionSMS,
    XClickToActionEmail,
    XClickToActionFacetime,
    XClickToActionAppstoreItunes,
    XClickToActionCalendar,
    
    } XClickToAction;

typedef enum{
    XMediationTargetedGenderFemale,
    XMediationTargetedGenderMale
} XMediationTargetedGender;

@protocol XAdViewDelegate;

@class XAdSlotConfiguration;
@class MPMoviePlayerController;


/*!
 @const XParameterCommandURL
 @discussion Key for parameter command URL
 */
FOUNDATION_EXPORT NSString * const XParameterCommandURL;

/*!
 @const XParameterCalendarStartDate
 @discussion Key for parameter calendar start date
 */
FOUNDATION_EXPORT NSString * const XParameterCalendarStartDate;

/*!
 @const XParameterCalendarEndDate
 @discussion Key for parameter calendar end date
 */
FOUNDATION_EXPORT NSString * const XParameterCalendarEndDate;

/*!
 @const XParameterCalendarSummary
 @discussion Key for parameter calendar summary
 */
FOUNDATION_EXPORT NSString * const XParameterCalendarSummary;

/*!
 @const XParameterCalendarDescription
 @discussion Key for parameter calendar description
 */
FOUNDATION_EXPORT NSString * const XParameterCalendarDescription;

/*!
 @const XParameterCalendarLocation
 @discussion Key for parameter calendar location
 */
FOUNDATION_EXPORT NSString * const XParameterCalendarLocation;

/*!
 @const XParameterCalendarReminder
 @discussion Key for parameter calendar reminder
 */
FOUNDATION_EXPORT NSString * const XParameterCalendarReminder;

/*!
 @const XParameterMailRecipient
 @discussion Key for parameter mail recipient(s)
 */
FOUNDATION_EXPORT NSString * const XParameterMailRecipient;

/*!
 @const XParameterMailSubject
 @discussion Key for parameter mail subject
 */
FOUNDATION_EXPORT NSString * const XParameterMailSubject;

/*!
 @const XParameterMailBody
 @discussion Key for parameter mail body
 */
FOUNDATION_EXPORT NSString * const XParameterMailBody;


@interface XAdView : UIView

/**
 *  @property delegate
 *  @brief The receiver's delegate
 *   The delegate is sent messages when ad is loading. See XAdViewDelegate Protocol Reference for the optional methods this delegate may implement.
 */
@property (nonatomic, weak) id<XAdViewDelegate> delegate;

/**
 *  @property slotConfiguration
 *  @brief The XAdSlotConfiguration instance for ad configuration
 */
@property (nonatomic, strong) XAdSlotConfiguration *slotConfiguration;

/**
 *  @property moviePlayerInstance
 *  @brief The MPMoviePlayerController instance used to display preroll ad
 */
@property (nonatomic, strong, setter = setMoviePlayerInstance:) MPMoviePlayerController *moviePlayerInstance;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name, ad position, postal code and query string.
 *
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 *  @param keywords     Comma separated values to filter the ads based on these keywords
 *  @param queryString  Key value pair for additional filtering of Ads
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition keywords:(NSString *)keywords queryString:(NSString *)queryString;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name, ad position, postal code and query string.
 *
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 *  @param queryString  Key value pair for additional filtering of Ads
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition queryString:(NSString *)queryString;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name and ad position.
 *
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 *  @param keywords     Comma separated values to filter the ads based on these keywords
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition keywords:(NSString *)keywords;

/**
 *  This method will be used to request ad from the server based on the page name and the container position. This method will take the domain name, page name and ad position.
 *
 *  @param domainName   Domain name of the server to request the ad
 *  @param pageName     Name of the page
 *  @param adPosition   Position of the ad where it needs to be displayed
 */
-(void)loadWithDomainName:(NSString *)domainName pageName:(NSString *)pageName adPosition:(NSString *)adPosition;

/**
 * Returns the current SDK version
 */
+(NSString *)appNexusOASSDKVersion;

/**
 *  Perform click to action
 *
 *  @param actionType The type of click to action that is requested
 *  @param parameters The key value pair used to create command URL or calendar event
 */
- (void) performClickToAction:(XClickToAction)actionType parameters:(NSDictionary *) parameters;
@end

@protocol XAdViewDelegate <NSObject>

@optional

/**
 * Sent when the interesitial ad is dismissed
 * This is for the internal use of SDK
 * Need not be implemented by publisher
 */
- (void) interstitialAdDismissed:(XAdView *)xadView;

/**
 * Sent when the interesitial ad is to be dismissed on memory warning
 * This is for the internal use of SDK
 * Need not be implemented by publisher
 */
- (void) interstitialAdDismissedOnMemoryWarning:(XAdView *)xadView;

/**
 * Detecting When a Ad is Loaded
 * Sent when an ad view successfully loads an ad.
 * Your implementation can add a view in hierarchy if you have not added it already
 
 * @param view The ad view sending the message.
 */

-(void)xAdViewDidLoad:(XAdView *)adView;

/**
 * Sent when an ad view fails to load an ad.
 *
 * If you have already added the ad view in the hierarchy, you must remove the view on this delegate call to avoid displaying of blank ads
 *
 * @param view The ad view sending the message.
 */
-(void)xAdView:(XAdView*)xAdView didFailWithError:(NSError *)error;

///**
// * Sent when server returns a blank ad.
// 
// * @param view The ad view sending the message.
// */

/**
 * Sent when user will click on a particular ad.
 *
 * @param view The ad view sending the message.
 */
-(void)xAdViewDidClickOnAd:(XAdView *)adView;

/**
 *  Sent when the banner ad expands
 *
 *  @param adView the expanded instance of the xAdView view
 */
-(void)xAdDidExpand:(XAdView *)adView;
/**
 *  Sent when the banner ad is collapsed to default state
 *
 *  @param adView the instance of XAdView
 */
-(void)xAdDidCollapse:(XAdView *)adView;

/**
 *  Sent after XAdView finishes playing or fails to play preroll ad.
 *
 *  @param xAdView           A XAdView object
 *  @param moviePlayerController MPMoviePlayerController which has finish loading preroll
 */
-(void)xAdView:(XAdView*) xadView prerollDidFinishWithPlayer:(MPMoviePlayerController*) moviePlayerController;

/**
 *  Sent when ad leaves the application to open a aurl in external browser
 *
 *  @param adView the expanded instance of the xAdView view
 */
-(void)xAdViewWillLeaveApplication:(XAdView *)adView;

/**
 *  Sent when the inapp browser is presented
 */
-(void)xAdViewWillOpenInInAppBrowser:(XAdView *)adView;
/**
 *  Sent when the inapp browser is closed
 *
 *  @param adView the instance of XAdView
 */
-(void)xAdViewWillCloseInAppBrowser:(XAdView *)adView;

/**
 *  Sent when XAdView has cleared the memory.
 *
 *  @param adView the instance of XAdView
 */
-(void)xAdViewDidDismissOnMemoryWarning:(XAdView *)adView;

/**
 *  Sent when Preroll video is paused.
 *
 *  @param adView the instance of XAdView
 *  @param currentTime the time at which the video is paused.
 */
-(void)xAdView :(XAdView*)xAdView didPauseVideo :(NSTimeInterval)currentTime;

/**
 *  Sent when Preroll video is Resumed.
 *
 *  @param adView the instance of XAdView
 *  @param currentTime the time at which the video is Resumed.
 */
-(void)xAdView :(XAdView*)xAdView didResume :(NSTimeInterval)currentTime;

/**
 *  Sent when Preroll video is skipped.
 *
 *  @param adView the instance of XAdView
 *  @param skipTime the time at which the video is skipped.
 */
-(void)xAdView :(XAdView*)xAdView didSkipVideo :(NSTimeInterval)skipTime;
/**
 *  Sent when Preroll video has finished a quartile.
 *
 *  @param adView the instance of XAdView
 *  @param quartile information about which quartile has been completed by the video.
 */
-(void)xAdView:(XAdView*)xAdView didFinishQuartile: (XVideoQuartile)quartile;
/**
 *  Sent when Preroll video enters full screen.
 *
 *  @param adView the instance of XAdView
 *
 */
-(void)xAdViewDidEnterFullScreen :(XAdView*)xAdView;
/**
 *  Sent when Preroll video exits full screen .
 *
 *  @param adView the instance of XAdView
 *
 */
-(void)xAdViewDidExitFullScreen :(XAdView*)xAdView;
/**
 *  Sent when Preroll video is rewound.
 *
 *  @param adView the instance of XAdView
 *
 */
-(void)xAdViewDidRewind:(XAdView*)xAdView ;

/**
 *  Asks the delegate if webview should display ad after webview finish rendering.
 *
 *  @param adView the instance of XAdView
 *  @param webView the instance of UIWebView
 */
-(BOOL)xAdView:(XAdView*)xAdView shouldDisplayAdOnWebViewFinishRender:(UIWebView *)webView;

/**
 *  Sent before a xadview perform click to action
 *
 *  @param xAdView    XAdView that is about to handle the click to action
 *  @param actionType The type of click to action that is requested
 *  @param parameters The key value pair used to create command URL or calendar event
 *
 *  @return YES if the xadview should handle click to action; otherwise, NO.
 */
- (BOOL)xAdView:(XAdView *)xAdView shouldHandleClickToAction:(XClickToAction)actionType parameters:(NSDictionary *) parameters;

/**
 *  Sent before a xadview handles a custom URL
 *
 *  @param xAdView    XAdView that is about to handle the click to action
 *  @param url The url to be handled by the publisher
 *
 *  @return YES if the xadview should handle this particular custom URL; otherwise, NO.
 */
- (void)xAdView:(XAdView *)xAdView shouldHandleCustomURL:(NSURL *)url;

@end