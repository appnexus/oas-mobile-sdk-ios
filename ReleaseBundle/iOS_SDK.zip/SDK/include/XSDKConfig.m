//
//  XSDKConfig.m
//  AppNexusOASSDK
//
//  Created by Developer on 6/4/14.
//  Copyright (c) 2014 AppNexusOAS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

bool enableDebugMode = NO;
