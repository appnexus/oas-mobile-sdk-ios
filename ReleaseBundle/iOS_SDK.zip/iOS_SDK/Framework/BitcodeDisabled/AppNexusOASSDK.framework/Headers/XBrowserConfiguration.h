//
//  XBrowserConfiguration.h
//  AppNexusOAS
//
//  Created by Developer on 4/9/15.
//  Copyright (c) 2015 AppNexusOAS. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    XToolbarButtonClose = 0,
    XToolbarButtonBack = 1,
    XToolbarButtonForward = 2,
    XToolbarButtonReload = 3,
    XToolbarButtonOpenInBrowser = 4
} XToolbarButtons;

typedef enum : NSUInteger {
    XToolbarPositionTop,
    XToolbarPositionBottom
} XToolbarPosition;

@interface XBrowserConfiguration : NSObject

/*
 * sets the toolbar position. uses XToolbarPosition enum
 */
@property (nonatomic) XToolbarPosition toolbarPosition;

/*
 * sets the color for toolbar
 */
@property (nonatomic, strong) UIColor *toolbarBGColor;

/*
 * sets the background image for toolbar
 */
@property (nonatomic, strong) NSString *toolbarBGImageName;

/*
 * sets the tool bar style
 */
@property (nonatomic) UIBarStyle barStyle;

/**
 @method setToolbarButton:withImageName
 @brief provides a way to display image on the tool bar buttons
 @param toolbarButton: tool bar button on which the image is to be shown
 @param buttonImage: image to display on the button
 **/
- (void) setToolbarButton:(XToolbarButtons) toolbarButton withImageName:(NSString *) buttonImage;

/**
 @method hideToolbarButton:withValue
 @brief provides a way to hide or show the buttons
 @param toolbarButton: tool bar button to show or hide
 @param visiblility: YES/NO YES: hide the toolbar button, NO: show the toolbar button
 **/
- (void) hideToolbarButton:(XToolbarButtons) toolbarButton withValue:(BOOL) visiblility;

@end

