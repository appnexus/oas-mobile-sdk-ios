
#import <UIKit/UIKit.h>
#import "XAdSlotConfiguration.h"
#import "XAdView.h"

@interface XMultipleBannerViewControllerWOD : UIViewController<XAdViewDelegate>

@end
