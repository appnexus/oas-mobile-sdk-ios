

#import <UIKit/UIKit.h>

@interface VASTAdViewControllerWOD : UIViewController

@end
