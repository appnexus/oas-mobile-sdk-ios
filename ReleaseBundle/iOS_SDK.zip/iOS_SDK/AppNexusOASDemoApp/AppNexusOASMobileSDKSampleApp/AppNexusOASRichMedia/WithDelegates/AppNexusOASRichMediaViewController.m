
#import "AppNexusOASRichMediaViewController.h"

@interface AppNexusOASRichMediaViewController (){
    NSDictionary *myParameters;
    XClickToAction myActionType;
}

@property(nonatomic,strong)XAdView *bannerAdView;

@end


@implementation AppNexusOASRichMediaViewController
@synthesize textView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [self initializingAd];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   [self orientationDidChange];
    
}

-(void)initializingAd
{
    /* Initialising the XAdView and fetching the ad */
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")) {
        self.edgesForExtendedLayout = UIRectEdgeNone; // For iOS 7 support.
    }
    
    self.bannerAdView = [[XAdView alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
    self.bannerAdView.delegate = self;
    self.bannerAdView.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:self.bannerAdView];
    
    XAdSlotConfiguration *configuration = [XAdSlotConfiguration new];
    [configuration setBackGroundImage:[UIImage imageNamed:@"320x50mobile_standard1.jpg"]];
    configuration.bannerRefreshInterval = 21.0f;
    configuration.scalingAllowed = YES;
    configuration.maintainAspectRatio = YES;
    configuration.RTBRequired = NO;
    configuration.mediationPlacementId = @"40";
    configuration.mediationBannerWidth = 320.0;
    configuration.mediationBannerHeight = 70.0;
    configuration.canMediate = YES;
    configuration.shouldOpenClickThroughURLInAppBrowser = YES;
    

    [self.bannerAdView setSlotConfiguration:configuration];
    
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"MSDK-Celtra-MRAID2-ExpandableBanner-a15e2c7e" adPosition:@"x25" keywords:nil queryString:nil];
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"MSDK-Opera-MRAID2-SimpleResize" adPosition:@"x25"];
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247media.com" pageName:@"www.SITE_MRAID_x42.com" adPosition:@"x42"];
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"MSDK-Opera-MRAID2-Expand-StayCentered" adPosition:@"x25"];
    
    //AppStore link
    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"MRAID_multiple_options/IABClickToActions" adPosition:@"Bottom"];

    //    [self.bannerAdView loadWithDomainName:@"delivery.uat.247media.com" pageName:@"MSDK-empty.gif" adPosition:@"x25"];
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"test_sms_body.com" adPosition:@"Bottom"];
    
    //MRAID Ad Test - Single-part Expandable
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"www.mraid2.0ads.com" adPosition:@"x01"];
    
    //MRAID Ad Test - MRAID Ad Designed to cause Errors
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"www.mraid2.0ads.com" adPosition:@"x05"];

    //MRAID Ad Test - Two part expandable
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"www.mraid2.0ads.com" adPosition:@"x02"];

    //template ad given by ramit for testing mraid2
//    [self.bannerAdView loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"mraid_template" adPosition:@"Bottom2"];
    
//    [self.bannerAdView loadWithDomainName:@"parisde.realads.com" pageName:@"www.meenaj.com" adPosition:@"Middle3"];
    
    NSLog(@"SDK Version: %@", [XAdView appNexusOASSDKVersion]);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)writeEntry:(NSString*)entry
{
    NSString* text = [self.textView.text stringByAppendingFormat:@"\n%@\n--", entry];
    self.textView.text = text;
    
    [self.textView scrollRangeToVisible:NSMakeRange(text.length, 0)];
}
#pragma mark XAdViewDelegates

-(void)xAdWillLoad:(XAdView *)adView
{
    
}

-(void)xAdViewDidLoad:(XAdView *)adView
{
    if (self.bannerAdView==adView)
    {
        [ self.view addSubview:adView];
    }
    [self writeEntry:@"xAdViewDidLoad: The Ad was loaded successfully"];
    NSLog(@"The ad was loaded successfully");
    
}

- (void)xAdView:(XAdView *)xAdView didFailWithError:(NSError *)error{
    [self writeEntry:[NSString stringWithFormat:@"xAdViewDidFailWithError: %@", [error localizedDescription]]];
}

- (void)xAdViewDidReceiveNoAd:(XAdView *)adView{
    [self writeEntry:@"didReceiveNoAd: The Ad was not recieved"];
    NSLog(@"Ad Response is nil.");
}

-(void)didClickOnAd:(XAdView *)adView{
    [self writeEntry:@"didClickOnAd: Did Click on Ad"];
}

- (void)xAdDidExpand:(XAdView *)adView{
    [self writeEntry:@"xadDidExpand: The Ad did expand"];
}

- (void)xAdDidCollapse:(XAdView *)adView{
    [self writeEntry:@"xadDidCollapse: The Ad did collapse"];
}

-(void)xAdViewWillOpenInInAppBrowser:(XAdView *)adView{
    [self writeEntry:@"xAdViewWillOpenInInAppBrowser: The Ad opened in Internal Browser"];
}

-(void)xAdViewWllLeaveApplication:(XAdView *)adView{
    [self writeEntry:@"xAdViewWllLeaveApplication: The Ad opened in External Browser"];
}
-(void)xAdViewWillCloseInAppBrowser:(XAdView *)adView{
    [self writeEntry:@"xAdViewWillCloseInAppBrowser: The Ad opened in will Close Inapp Browser"];
}

- (void)xAdViewDidDismissOnMemoryWarning:(XAdView *)adView{
//    [self.bannerAdView removeFromSuperview];
    [self writeEntry:@"xAdViewDidDismissOnMemoryWarning: Received Memory Warning"];
}

- (BOOL)xAdView:(XAdView *)xAdView webViewDidFinishRender:(UIWebView *)webView{
    
    [self writeEntry:@"webViewDidFinishRender: web view finished rendering the ad."];
    return NO;
    
}

- (BOOL)xAdView:(XAdView *)xAdView shouldHandleClickToAction:(XClickToAction)actionType parameters:(NSDictionary *) parameters
{
    myActionType = actionType;
    myParameters = parameters;
    
    BOOL returnVal = YES;

    switch (actionType) {
            
//        case XClickToActionOpenBrowser:
//        {
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"<Alert message for ""open browser"" goes here?>" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
//            [alertView show];
//            returnVal = NO;
//        }
//            break;
        case XClickToActionCall:
        {
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"<Alert message for ""call"" goes here?>" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
            [alertView show];
            returnVal = NO;
        }
            break;
        case XClickToActionEmail:
        case XClickToActionSMS:
        case XClickToActionAppstoreItunes:
        case XClickToActionCalendar:
        default:
            break;
    }
    
    return returnVal;
}

#pragma mark - UIAlertViewDelegate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == alertView.cancelButtonIndex)
    {
        //Do nothing
    }
    else if (buttonIndex == alertView.firstOtherButtonIndex)
    {
        [self.bannerAdView performClickToAction:myActionType parameters:myParameters];
    }
}

#pragma mark orientation
-(BOOL)shouldAutorotate
{
    
    [self orientationDidChange];
    
    return YES;
}

-(void) orientationDidChange
{

    CGRect bounds = [[UIScreen mainScreen] bounds]; // portrait bounds
    if (UIInterfaceOrientationIsLandscape([[UIApplication sharedApplication] statusBarOrientation]) && NSFoundationVersionNumber <= NSFoundationVersionNumber_iOS_7_1) {
        bounds.size = CGSizeMake(bounds.size.height, bounds.size.width);
    }
    
    CGRect frame = self.bannerAdView.frame;
    frame.origin.x = (bounds.size.width - self.bannerAdView.frame.size.width)/2;
    self.bannerAdView.frame = frame;

    if(([[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeRight|| [[UIApplication sharedApplication] statusBarOrientation] == UIInterfaceOrientationLandscapeLeft))
    {
        self.textView.frame = CGRectMake(20, 100,self.view.frame.size.width-40, 150);
        //        self.bannerAdView.frame =  CGRectMake(0, 0, 320, 50);
    }
    else
    {
        self.textView.frame = CGRectMake(20, 80, self.view.frame.size.width-40, 250);
        //        self.bannerAdView.frame =  CGRectMake(0, 0, 320, 50);
    }
    
    
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    [self orientationDidChange];
    return YES;
}

- (BOOL)xAdView:(XAdView *)xAdView shouldDisplayAdOnWebViewFinishRender:(UIWebView *)webView{
    
    return YES;

}

@end
