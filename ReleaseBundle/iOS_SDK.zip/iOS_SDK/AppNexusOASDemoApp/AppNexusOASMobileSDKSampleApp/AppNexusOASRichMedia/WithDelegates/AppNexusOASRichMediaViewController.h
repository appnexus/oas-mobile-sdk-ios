
#import <UIKit/UIKit.h>
#import "XAdView.h"
#import "XAdSlotConfiguration.h"

@interface AppNexusOASRichMediaViewController : UIViewController<XAdViewDelegate>

@property (nonatomic, strong)IBOutlet UITextView* textView;


@end
