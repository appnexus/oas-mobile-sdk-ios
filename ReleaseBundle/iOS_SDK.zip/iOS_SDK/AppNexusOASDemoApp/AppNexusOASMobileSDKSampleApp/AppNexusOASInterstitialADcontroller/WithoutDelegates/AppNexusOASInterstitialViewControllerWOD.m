#import "AppNexusOASInterstitialViewControllerWOD.h"
#import "XAdSlotConfiguration.h"

@interface AppNexusOASInterstitialViewControllerWOD ()

@end

@implementation AppNexusOASInterstitialViewControllerWOD
@synthesize adType,interestitial;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil adType:(NSString *)currentAdType
{
    self = [self initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.adType = currentAdType;
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = NO;
    [self presentInterstitialAd];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Other Methods

-(void)presentInterstitialAd
{
    interestitial = [[XAdInterstitialViewController alloc] init];
    interestitial.delegate = self;
    XAdSlotConfiguration *configuration = [[XAdSlotConfiguration alloc] init];
    configuration.bannerRefreshInterval = 0.0f;
    configuration.canMediate = YES;
    configuration.mediationPlacementId = @"61";
    configuration.shouldOpenClickThroughURLInAppBrowser = NO;
    configuration.countdownTimerPosition = XCountdownTimerPositionTopRight;
    
    [interestitial setSlotConfiguration:configuration];
    
    [self presentViewController:interestitial animated:YES completion:nil];
    
    
    if ([self.adType isEqualToString:@"mraid"])
    {
        [interestitial loadWithDomainName:@"delivery.uat.247realmedia.com" pageName:@"MSDK-Joule-interstitial-TF1_Eurosport_iPhone_RM_int-249058" adPosition:@"@x93" ];
    }
    else if([self.adType isEqualToString:@"vast"])
    {
        [interestitial loadWithDomainName:@"openad.tf1.fr" pageName:@"vast_preroll" adPosition:@"Bottom"];
    }
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

-(BOOL)shouldAutorotate
{
   return YES;    
}

@end
